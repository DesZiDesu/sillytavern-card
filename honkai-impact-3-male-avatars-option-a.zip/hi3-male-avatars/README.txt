HI3 male avatars — curated official-source artwork normalized to 256x256 PNG for the SillyTavern gallery.
